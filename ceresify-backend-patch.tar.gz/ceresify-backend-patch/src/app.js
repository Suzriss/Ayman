const express = require('express');
const connectDB = require('./config/db');
require('dotenv').config();

const app = express();

// Connect DB
connectDB();

// Device routes FIRST (قبل أي body parser)
const deviceRoutes = require('./routes/device');
app.use('/api/device', deviceRoutes);

// Middleware (بعد device routes)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// باقي الـ routes
const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

const signRoutes = require('./routes/sign');
app.use('/api/sign', signRoutes);

const adminRoutes = require('./routes/admin');
app.use('/api/admin', adminRoutes);
const dealerRoutes = require('./routes/dealers');
app.use('/api/dealers', dealerRoutes);

const ahmadRoutes = require('./routes/ahmad');
app.use('/api/ahmad', ahmadRoutes);

// مصغّرات أيقونات التطبيقات
app.use('/api/thumb', require('./routes/thumb'));

// واجهات عامة لتطبيق الآيفون: /api/repo.json و /api/categories (بنرات وتصنيفات لوحة التحكم)
app.use('/api', require('./routes/store'));

// Root
app.get('/', (req, res) => {
  res.json({ message: '🚀 Ceresify API Running' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
});
