//
//  CeresifyAuth.swift
//  SY STORE
//
//  التحقق من الاشتراك عبر لوحة Ceresify.
//  اللوحة تعرّف المشترك بالـ UDID (يجي من الـ mobileconfig enrollment)، وتطبيق iOS
//  ما يكدر يقرا UDID. فكود التفعيل نفسه هو جسر الهوية: نرسله للسيرفر وهو يحله
//  إلى المشترك المرتبط بيه ويرجّع حالة اشتراكه.
//

import SwiftUI
import UIKit

enum Ceresify {
    static let baseURL = "https://dev.ceresify.com"
    static var repoURL: String { "\(baseURL)/api/app/repo.json" }
}

@MainActor
final class CeresifyAuth: ObservableObject {
    static let shared = CeresifyAuth()

    @Published var isAuthorized = false
    @Published var isChecking = true
    @Published var errorMessage: String?
    @Published var expiresAt: Date?

    private var pollTimer: Timer?

    private let codeKey = "ceresify.activationCode"
    private let deviceKey = "ceresify.deviceId"
    private let repoKey = "ceresify.didAddRepo"
    private let certKey = "ceresify.didImportCert"

    /// identifierForVendor — يثبت طول ما التطبيق منصّب، ويتبدل لو انحذف وانعاد تنصيبه.
    /// نخزنه بالـ UserDefaults حتى يبقى ثابت عبر التحديثات.
    var deviceId: String {
        if let saved = UserDefaults.standard.string(forKey: deviceKey) { return saved }
        let new = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(new, forKey: deviceKey)
        return new
    }

    var savedCode: String? { UserDefaults.standard.string(forKey: codeKey) }

    private init() {}

    func start() {
        guard let code = savedCode else {
            isChecking = false
            isAuthorized = false
            return
        }
        Task { await verify(code: code, silent: true) }
    }

    // MARK: - التحقق

    func verify(code rawCode: String, silent: Bool = false) async {
        let code = rawCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty else { return }

        isChecking = true
        if !silent { errorMessage = nil }

        guard let url = URL(string: "\(Ceresify.baseURL)/api/app/verify") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 20
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "code": code,
            "deviceId": deviceId,
            "deviceName": UIDevice.current.name
        ])

        do {
            let (data, _) = try await URLSession.shared.data(for: request)
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw URLError(.cannotParseResponse)
            }

            if json["ok"] as? Bool == true {
                UserDefaults.standard.set(code, forKey: codeKey)
                expiresAt = (json["expiresAt"] as? String).flatMap(Self.parseDate)
                isAuthorized = true
                errorMessage = nil
                startPolling(code: code)
                await syncRepo(code: code)
                if json["hasCert"] as? Bool == true { await importCert(code: code) }
            } else {
                signOut(message: json["message"] as? String ?? "تعذر التحقق من الاشتراك")
            }
        } catch {
            // فشل شبكة — ما نطرد مشترك داخل أصلاً، بس ما نخلي أحد جديد يدخل
            if !isAuthorized {
                errorMessage = "تعذر الاتصال بالخادم — تأكد من الإنترنت."
            }
        }

        isChecking = false
    }

    /// فحص دوري خفيف: يمسك التجميد وانتهاء الاشتراك ونقل الكود لجهاز ثاني.
    private func startPolling(code: String) {
        pollTimer?.invalidate()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            Task { @MainActor in await self?.pollStatus(code: code) }
        }
    }

    private func pollStatus(code: String) async {
        var components = URLComponents(string: "\(Ceresify.baseURL)/api/app/status")
        components?.queryItems = [
            URLQueryItem(name: "code", value: code),
            URLQueryItem(name: "deviceId", value: deviceId)
        ]
        guard let url = components?.url else { return }

        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            // خطأ سيرفر ما يطرد أحد
            if let http = response as? HTTPURLResponse, http.statusCode >= 500 { return }
            guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            if json["ok"] as? Bool == true {
                expiresAt = (json["expiresAt"] as? String).flatMap(Self.parseDate)
            } else if (json["reason"] as? String) != "server" {
                signOut(message: json["message"] as? String ?? "انتهت جلستك")
            }
        } catch {
            // انقطاع إنترنت مؤقت — نتجاهله
        }
    }

    func signOut(message: String?) {
        pollTimer?.invalidate()
        pollTimer = nil
        UserDefaults.standard.removeObject(forKey: codeKey)
        UserDefaults.standard.removeObject(forKey: repoKey)
        isAuthorized = false
        expiresAt = nil
        errorMessage = message
        isChecking = false
    }

    // MARK: - المصدر والشهادة

    /// يضيف مستودع اللوحة كمصدر افتراضي (مرة وحدة).
    private func syncRepo(code: String) async {
        guard !UserDefaults.standard.bool(forKey: repoKey) else { return }
        let source = "\(Ceresify.repoURL)?code=\(code)&deviceId=\(deviceId)"
        FR.handleSource(source) {
            UserDefaults.standard.set(true, forKey: self.repoKey)
        }
    }

    /// يسحب شهادة توقيع المشترك من اللوحة وينصبها (مرة وحدة لكل كود).
    private func importCert(code: String) async {
        let marker = "\(certKey).\(code)"
        guard !UserDefaults.standard.bool(forKey: marker) else { return }

        func download(_ kind: String) async -> URL? {
            var components = URLComponents(string: "\(Ceresify.baseURL)/api/app/cert/\(kind)")
            components?.queryItems = [
                URLQueryItem(name: "code", value: code),
                URLQueryItem(name: "deviceId", value: deviceId)
            ]
            guard let url = components?.url else { return nil }
            guard let (data, response) = try? await URLSession.shared.data(from: url),
                  let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            let dest = FileManager.default.temporaryDirectory
                .appendingPathComponent(UUID().uuidString)
                .appendingPathExtension(kind == "p12" ? "p12" : "mobileprovision")
            do { try data.write(to: dest); return dest } catch { return nil }
        }

        // كلمة سر الشهادة تجي من /cert/info
        var infoComponents = URLComponents(string: "\(Ceresify.baseURL)/api/app/cert/info")
        infoComponents?.queryItems = [
            URLQueryItem(name: "code", value: code),
            URLQueryItem(name: "deviceId", value: deviceId)
        ]
        var password = ""
        if let infoURL = infoComponents?.url,
           let (data, _) = try? await URLSession.shared.data(from: infoURL),
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            guard json["hasCert"] as? Bool == true else { return }
            password = json["password"] as? String ?? ""
        }

        guard let p12 = await download("p12"),
              let prov = await download("mobileprovision") else { return }

        guard FR.checkPasswordForCertificate(for: p12, with: password, using: prov) else { return }

        FR.handleCertificateFiles(
            p12URL: p12,
            provisionURL: prov,
            p12Password: password,
            certificateName: "Ceresify",
            isDefault: true
        ) { error in
            if error == nil { UserDefaults.standard.set(true, forKey: marker) }
        }
    }

    private static func parseDate(_ string: String) -> Date? {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter.date(from: string) ?? ISO8601DateFormatter().date(from: string)
    }
}
