const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const App = require('../models/App');
const ActivationCode = require('../models/ActivationCode');
const multer = require('multer');
const fs = require('fs');
const { extractIpaInfo } = require('../utils/ipaInfo');

const APP_ROOT_A = process.env.APP_ROOT || '/var/www/ceresify';
const _up = (sub) => require('path').join(APP_ROOT_A, 'uploads', sub);

const ADMIN_USER = process.env.ADMIN_USERNAME || 'ayman';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'ceresify2026';
const JWT_SECRET = process.env.JWT_SECRET || 'ceresify_secret';

function adminAuth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') throw new Error('Not admin');
    next();
  } catch (e) {
    res.status(401).json({ message: 'Invalid token' });
  }
}

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    const token = jwt.sign({ role: 'admin', username }, JWT_SECRET, { expiresIn: '7d' });
    return res.json({ ok: true, token });
  }
  res.status(401).json({ ok: false, message: 'Invalid credentials' });
});

router.get('/verify', adminAuth, (req, res) => {
  res.json({ ok: true });
});

router.get('/apps', adminAuth, async (req, res) => {
  const apps = await App.find().sort({ createdAt: -1 });
  res.json({ apps });
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // الأيقونة تروح لمجلد icons، والـ IPA لمجلد ipa
    const dir = file.fieldname === 'banner'
      ? _up('banners')
      : file.fieldname === 'icon'
      ? _up('icons')
      : _up('ipa');
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random()*1e6);
    const extn = (file.fieldname === 'icon' || file.fieldname === 'banner') ? '.png' : '.ipa';
    cb(null, unique + extn);
  }
});
const upload = multer({ storage, limits: { fileSize: 500 * 1024 * 1024 } });

router.post('/apps/upload', adminAuth, upload.fields([{ name: 'ipa', maxCount: 1 }, { name: 'icon', maxCount: 1 }]), async (req, res) => {
  try {
    const ipaFile  = req.files && req.files.ipa  ? req.files.ipa[0]  : null;
    const iconFile = req.files && req.files.icon ? req.files.icon[0] : null;
    if (!ipaFile) return res.status(400).json({ ok: false, message: 'No file uploaded' });

    const absIpa = ipaFile.path;
    const ipaPath = `/uploads/ipa/${ipaFile.filename}`;

    // استخراج المعلومات الحقيقية من داخل الـ IPA (مصدر الحقيقة — يمنع مشكلة bundleId)
    let ext = {};
    try {
      ext = extractIpaInfo(absIpa) || {};
    } catch (e) {
      fs.unlinkSync(absIpa);
      return res.status(400).json({ ok: false, message: 'تعذّر قراءة الـ IPA: ' + e.message });
    }

    const cleanupTmp = () => { if (ext._workDir) { try { fs.rmSync(ext._workDir, { recursive: true, force: true }); } catch(_){} } };

    // bundleId والـ version يُؤخذان من الـ IPA إجبارياً (لا إدخال يدوي)
    const bundleId = ext.bundleId;
    if (!bundleId) {
      cleanupTmp(); fs.unlinkSync(absIpa);
      return res.status(400).json({ ok: false, message: 'لم نستطع استخراج bundleId من الـ IPA — ملف غير صالح' });
    }

    // منع التكرار: نفس bundleId موجود مسبقاً
    const existing = await App.findOne({ bundleId });
    if (existing) {
      cleanupTmp(); fs.unlinkSync(absIpa);
      return res.status(409).json({ ok: false, message: `تطبيق بنفس bundleId موجود مسبقاً (${bundleId}) — احذف القديم أولاً` });
    }

    // الاسم والفئة: يسمح للأدمن يعدّلهم، وإلا ياخذ من الـ IPA
    const name    = (req.body.name && req.body.name.trim()) || ext.name || 'App';
    const version = ext.shortVersion || ext.version || '1.0';
    const category = (req.body.category && req.body.category.trim()) || 'General';
    const description = (req.body.description && req.body.description.trim()) || null;

    // الأيقونة: لو رفع الأدمن صورة نستخدمها، وإلا نستخرج من الـ IPA
    let iconUrl = null;
    if (iconFile) {
      iconUrl = `/uploads/icons/${iconFile.filename}`;
    } else if (ext.iconPath && fs.existsSync(ext.iconPath)) {
      try {
        const iconDir = _up('icons');
        fs.mkdirSync(iconDir, { recursive: true });
        const iconName = Date.now() + '-' + Math.round(Math.random()*1e6) + '.png';
        fs.copyFileSync(ext.iconPath, `${iconDir}/${iconName}`);
        iconUrl = `/uploads/icons/${iconName}`;
      } catch (_) { /* الأيقونة اختيارية */ }
    }
    // نظّف المجلد المؤقت اللي خلّفه extractIpaInfo (عشان ما تتراكم)
    if (ext._workDir) { try { fs.rmSync(ext._workDir, { recursive: true, force: true }); } catch(_){} }

    const app = new App({
      name, bundleId, version, category, iconUrl, description,
      ipaPath, size: ipaFile.size
    });
    await app.save();
    res.json({ ok: true, app, extracted: { name: ext.name, bundleId, version } });
  } catch(e) {
    if (req.files && req.files.ipa && fs.existsSync(req.files.ipa[0].path)) { try { fs.unlinkSync(req.files.ipa[0].path); } catch(_){} }
    res.status(500).json({ ok: false, message: e.message });
  }
});

router.post('/apps', adminAuth, async (req, res) => {
  try {
    const app = new App(req.body);
    await app.save();
    res.json({ ok: true, app });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

router.put('/apps/:id', adminAuth, upload.single('icon'), async (req, res) => {
  try {
    const update = {};
    // الحقول النصية: تُحدّث فقط لو أُرسلت
    if (req.body.name !== undefined)        update.name = req.body.name;
    if (req.body.bundleId !== undefined)    update.bundleId = req.body.bundleId;
    if (req.body.version !== undefined)     update.version = req.body.version;
    if (req.body.category !== undefined)    update.category = req.body.category;
    if (req.body.description !== undefined)  update.description = req.body.description;

    // لو رفع الأدمن صورة جديدة → نستبدل الأيقونة (وإلا تبقى المستخرَجة من الـ IPA)
    if (req.file) {
      update.iconUrl = `/uploads/icons/${req.file.filename}`;
    }

    const app = await App.findByIdAndUpdate(req.params.id, update, { new: true });
    res.json({ ok: true, app });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

router.delete('/apps/:id', adminAuth, async (req, res) => {
  await App.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

router.get('/codes', adminAuth, async (req, res) => {
  const codes = await ActivationCode.find().sort({ createdAt: -1 }).limit(200);
  res.json({ codes });
});

router.post('/codes/generate', adminAuth, async (req, res) => {
  try {
    const { count = 1, duration = 30 } = req.body;
    const { v4: uuidv4 } = require('uuid');
    const codes = [];
    for (let i = 0; i < Math.min(count, 100); i++) {
      const _h = uuidv4().replace(/-/g,'').toUpperCase(); const code = 'CRS-' + _h.slice(0,4) + '-' + _h.slice(4,8);
      const activation = new ActivationCode({ code, duration });
      await activation.save();
      codes.push(activation);
    }
    res.json({ ok: true, codes });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

router.get('/codes/:id/user', adminAuth, async (req, res) => {
  try {
    const code = await ActivationCode.findById(req.params.id);
    if (!code || !code.usedBy) return res.status(404).json({ message: 'Not found' });
    const user = await User.findById(code.usedBy);
    res.json({ user });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

router.get('/users', adminAuth, async (req, res) => {
  try {
    const users = await User.find({ subscriptionExpiry: { $gt: new Date() } }).sort({ createdAt: -1 });
    const today = new Date(); today.setHours(0,0,0,0);
    const todayCount = users.filter(u => new Date(u.createdAt) >= today).length;
    const countries = [...new Set(users.map(u => u.country).filter(Boolean))].length;
    res.json({ users, stats: { total: users.length, today: todayCount, countries } });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

router.post('/users/:id/revoke', adminAuth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.id, { isSubscribed: false, activationCode: null });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
});

// ═══ السورسات (repos خارجية) ═══
const Source = require('../models/Source');
const axios = require('axios');

// جلب قائمة السورسات
router.get('/sources', adminAuth, async (req, res) => {
  const sources = await Source.find().sort({ createdAt: -1 });
  res.json({ sources });
});

// إضافة سورس + جلب معلوماته (الاسم، الأيقونة، عدد التطبيقات)
router.post('/sources', adminAuth, async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ ok: false, message: 'رابط مطلوب' });
    const existing = await Source.findOne({ url });
    if (existing) return res.status(409).json({ ok: false, message: 'السورس موجود مسبقاً' });

    // نجلب السورس عشان نقرأ اسمه وعدد تطبيقاته
    let name = url, iconUrl = null, appCount = 0;
    try {
      const resp = await axios.get(url, { timeout: 20000, maxContentLength: 50*1024*1024 });
      const data = resp.data;
      name = data.name || url;
      iconUrl = data.iconURL || data.META?.repoIcon || null;
      appCount = Array.isArray(data.apps) ? data.apps.length : 0;
    } catch (e) {
      return res.status(502).json({ ok: false, message: 'تعذّر جلب السورس: ' + e.message });
    }

    const source = await Source.create({ url, name, iconUrl, appCount, lastFetch: new Date() });
    res.json({ ok: true, source });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// حذف سورس
router.delete('/sources', adminAuth, async (req, res) => {
  const { url, id } = req.body;
  if (id) await Source.findByIdAndDelete(id);
  else if (url) await Source.deleteOne({ url });
  res.json({ ok: true });
});

// ══════════ مفتاح تفعيل مصدر أحمد (type=ahmadup) ══════════
// هذا مستند Source واحد يشتغل كـ "مفتاح تشغيل" فقط — ahmad-categories, ahmad-apps,
// وواجهة /api/repo.json العامة كلها تتوقف عليه (Source.findOne({type:'ahmadup', isActive:true})).
// بدونه كل شي يرجع فاضي (تطبيقات، فئات، بنرات) حتى لو مفاتيح AHMADUP_KEY/TOKEN صحيحة.

router.get('/ahmad-source', adminAuth, async (req, res) => {
  try {
    const src = await Source.findOne({ type: 'ahmadup' });
    res.json({ ok: true, enabled: !!(src && src.isActive), source: src || null });
  } catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});

router.post('/ahmad-source/toggle', adminAuth, async (req, res) => {
  try {
    const active = req.body.isActive !== false; // ما أرسل شي = تفعيل
    let src = await Source.findOne({ type: 'ahmadup' });
    if (src) {
      src.isActive = active;
      await src.save();
    } else {
      src = await Source.create({
        url: 'ahmad-up-integration',
        name: 'Ahmad Up',
        type: 'ahmadup',
        isActive: active
      });
    }
    res.json({ ok: true, enabled: active, source: src });
  } catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});

// جلب تطبيقات سورس معيّن (للعرض بالمتجر)
router.get('/sources/:id/apps', adminAuth, async (req, res) => {
  try {
    const source = await Source.findById(req.params.id);
    if (!source) return res.status(404).json({ ok: false, message: 'السورس غير موجود' });
    const resp = await axios.get(source.url, { timeout: 20000, maxContentLength: 50*1024*1024 });
    const apps = (resp.data.apps || []).map(a => ({
      name: a.name,
      bundleId: a.bundleIdentifier || a.bundleID,
      version: a.version,
      downloadURL: a.downloadURL,
      iconURL: a.iconURL || a.icon,
      size: a.size,
      developer: a.developerName,
      description: a.localizedDescription
    }));
    res.json({ ok: true, apps, count: apps.length });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// ═══ الفئات (Categories) ═══
const Category = require('../models/Category');

// قائمة الفئات مرتبة حسب order
router.get('/categories', adminAuth, async (req, res) => {
  try {
    const categories = await Category.find().sort({ order: 1, createdAt: 1 });
    res.json({ categories });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// إضافة فئة
router.post('/categories', adminAuth, async (req, res) => {
  try {
    let { name, slug, icon, order } = req.body;
    if (!name || !slug) return res.status(400).json({ ok: false, message: 'الاسم والمعرّف (slug) مطلوبان' });
    slug = String(slug).trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
    const existing = await Category.findOne({ slug });
    if (existing) return res.status(409).json({ ok: false, message: 'فئة بنفس المعرّف موجودة مسبقاً' });
    // لو ما أُرسل order، نحطها آخر الترتيب
    if (order === undefined || order === null || order === '') {
      const last = await Category.findOne().sort({ order: -1 });
      order = last ? (last.order || 0) + 1 : 0;
    }
    const category = await Category.create({ name: name.trim(), slug, icon: (icon || 'fa-folder').trim(), order: Number(order) || 0 });
    res.json({ ok: true, category });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// إعادة ترتيب — يستقبل array من {id, order}
// مهم: هذا الراوت لازم يُسجَّل قبل PUT /categories/:id وإلا Express يعتبر "reorder" قيمة :id
router.put('/categories/reorder', adminAuth, async (req, res) => {
  try {
    const items = Array.isArray(req.body) ? req.body : (req.body.items || req.body.order);
    if (!Array.isArray(items)) return res.status(400).json({ ok: false, message: 'مصفوفة {id, order} مطلوبة' });
    await Promise.all(items.map(it =>
      Category.findByIdAndUpdate(it.id, { order: Number(it.order) || 0 })
    ));
    const categories = await Category.find().sort({ order: 1, createdAt: 1 });
    res.json({ ok: true, categories });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// تعديل فئة
router.put('/categories/:id', adminAuth, async (req, res) => {
  try {
    const update = {};
    if (req.body.name !== undefined)     update.name = String(req.body.name).trim();
    if (req.body.icon !== undefined)     update.icon = String(req.body.icon).trim();
    if (req.body.order !== undefined)    update.order = Number(req.body.order) || 0;
    if (req.body.isActive !== undefined) update.isActive = !!req.body.isActive;
    if (req.body.slug !== undefined) {
      const slug = String(req.body.slug).trim().toLowerCase().replace(/[^a-z0-9-]/g, '-');
      const dup = await Category.findOne({ slug, _id: { $ne: req.params.id } });
      if (dup) return res.status(409).json({ ok: false, message: 'فئة بنفس المعرّف موجودة مسبقاً' });
      update.slug = slug;
    }
    const category = await Category.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!category) return res.status(404).json({ ok: false, message: 'الفئة غير موجودة' });
    res.json({ ok: true, category });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// حذف فئة
router.delete('/categories/:id', adminAuth, async (req, res) => {
  try {
    await Category.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});


// ─────────── البنرات ───────────
const Banner = require('../models/Banner');

// قائمة البنرات (أدمن)
router.get('/banners', adminAuth, async (req, res) => {
  const banners = await Banner.find().sort({ order: 1, createdAt: 1 });
  res.json({ banners });
});

// رفع بنر جديد (صورة + رابط)
router.post('/banners', adminAuth, upload.single('banner'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ ok: false, message: 'لا توجد صورة' });
    const imageUrl = `/uploads/banners/${req.file.filename}`;
    const count = await Banner.countDocuments();
    const banner = await Banner.create({
      imageUrl,
      linkUrl: (req.body.linkUrl || '').trim(),
      order: count
    });
    res.json({ ok: true, banner });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// حذف بنر
router.delete('/banners/:id', adminAuth, async (req, res) => {
  try {
    await Banner.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});


const Product = require('../models/Product');
const APP_ROOT_P = process.env.APP_ROOT || '/var/www/ceresify';
const productStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = require('path').join(APP_ROOT_P, 'uploads/products');
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + Math.round(Math.random()*1e6) + '.png');
  }
});
const productUpload = multer({ storage: productStorage, limits: { fileSize: 10 * 1024 * 1024 } });
router.get('/products', adminAuth, async (req, res) => {
  try { const products = await Product.find().sort({ order: 1, createdAt: -1 }); res.json({ ok: true, products }); }
  catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});
router.post('/products', adminAuth, productUpload.single('image'), async (req, res) => {
  try {
    const { name, price, description } = req.body || {};
    if (!name) return res.status(400).json({ ok: false, message: 'الاسم مطلوب' });
    let imageUrl = null;
    if (req.file) imageUrl = '/uploads/products/' + req.file.filename;
    const p = await Product.create({ name, price: price || null, description: description || null, imageUrl });
    res.json({ ok: true, product: p });
  } catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});
router.put('/products/:id', adminAuth, productUpload.single('image'), async (req, res) => {
  try {
    const { name, price, description, isActive } = req.body || {};
    const update = {};
    if (name !== undefined) update.name = name;
    if (price !== undefined) update.price = price;
    if (description !== undefined) update.description = description;
    if (isActive !== undefined) update.isActive = (isActive === 'true' || isActive === true);
    if (req.file) update.imageUrl = '/uploads/products/' + req.file.filename;
    const p = await Product.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!p) return res.status(404).json({ ok: false, message: 'المنتج غير موجود' });
    res.json({ ok: true, product: p });
  } catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});
router.delete('/products/:id', adminAuth, async (req, res) => {
  try { await Product.findByIdAndDelete(req.params.id); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, message: e.message }); }
});


// ══════════ التحكم بتصنيفات مصدر أحمد ══════════
const CategoryOverride = require('../models/CategoryOverride');

// جلب كل تصنيفات أحمد مع حالة التحكم
router.get('/ahmad-categories', adminAuth, async (req, res) => {
  try {
    const Source = require('../models/Source');
    const ahmadSrc = await Source.findOne({ type: 'ahmadup', isActive: true });
    let liveCats = [];
    if (ahmadSrc) {
      const { fetchAllAhmad } = require('../utils/ahmadFetch');
      const apps = await fetchAllAhmad();
      const counts = {};
      for (const a of apps) { const c=(a.category||'').trim(); if(c) counts[c]=(counts[c]||0)+1; }
      liveCats = Object.keys(counts).map(name => ({ name, count: counts[name] }));
    }
    // نجيب الـ overrides
    const overrides = await CategoryOverride.find({});
    const ovMap = {}; overrides.forEach(o => { if(o.originalName) ovMap[o.originalName]=o; });

    // ندمج
    const result = liveCats.map(c => {
      const ov = ovMap[c.name];
      return {
        _id: ov ? ov._id : null,
        originalName: c.name,
        displayName: ov?.displayName || c.name,
        icon: ov?.icon || null,
        hidden: ov?.hidden || false,
        order: ov?.order ?? 999,
        count: c.count,
        isCustom: false
      };
    });
    // نضيف التصنيفات المخصصة
    const customs = overrides.filter(o => o.isCustom).map(o => ({
      _id: o._id, originalName: null, displayName: o.displayName,
      icon: o.icon, hidden: o.hidden, order: o.order,
      count: (o.customApps||[]).length, isCustom: true, customApps: o.customApps
    }));

    const all = [...result, ...customs].sort((a,b)=> (a.order-b.order) || a.displayName.localeCompare(b.displayName));
    res.json({ ok: true, categories: all });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// حفظ/تعديل override لتصنيف
router.post('/ahmad-categories/override', adminAuth, async (req, res) => {
  try {
    const { originalName, displayName, icon, hidden, order } = req.body;
    if (!originalName) return res.status(400).json({ ok:false, message:'originalName مطلوب' });
    const update = {};
    if (displayName !== undefined) update.displayName = displayName;
    if (icon !== undefined) update.icon = icon;
    if (hidden !== undefined) update.hidden = !!hidden;
    if (order !== undefined) update.order = Number(order);
    const ov = await CategoryOverride.findOneAndUpdate(
      { originalName }, { $set: update }, { upsert: true, new: true }
    );
    res.json({ ok: true, override: ov });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// إعادة ترتيب دفعة وحدة
router.post('/ahmad-categories/reorder', adminAuth, async (req, res) => {
  try {
    const { items } = req.body; // [{originalName، order}]
    if (!Array.isArray(items)) return res.status(400).json({ ok:false, message:'items مطلوبة' });
    for (const it of items) {
      if (it.originalName) {
        await CategoryOverride.findOneAndUpdate({ originalName: it.originalName }, { $set:{ order: Number(it.order) } }, { upsert: true });
      } else if (it._id) {
        await CategoryOverride.findByIdAndUpdate(it._id, { $set:{ order: Number(it.order) } });
      }
    }
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// إنشاء تصنيف مخصص
router.post('/ahmad-categories/custom', adminAuth, async (req, res) => {
  try {
    const { displayName, icon, customApps } = req.body;
    if (!displayName) return res.status(400).json({ ok:false, message:'الاسم مطلوب' });
    const ov = await CategoryOverride.create({
      isCustom: true, displayName, icon: icon||null,
      customApps: Array.isArray(customApps)?customApps:[], order: 0
    });
    res.json({ ok: true, category: ov });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// حذف override أو تصنيف مخصص
router.delete('/ahmad-categories/:id', adminAuth, async (req, res) => {
  try {
    await CategoryOverride.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});



// ══════════ التحكم بتطبيقات مصدر أحمد ══════════
const AppOverride = require('../models/AppOverride');

// بحث/تصفّح التطبيقات (بالاسم أو بالتصنيف) مع حالة التحكم
router.get('/ahmad-apps', adminAuth, async (req, res) => {
  try {
    const q = (req.query.q || '').trim().toLowerCase();
    const category = (req.query.category || '').trim();
    const limit = Math.min(200, parseInt(req.query.limit) || 60);

    const Source = require('../models/Source');
    const ahmadSrc = await Source.findOne({ type: 'ahmadup', isActive: true });
    if (!ahmadSrc) return res.json({ ok: true, apps: [], total: 0 });

    const { fetchAllAhmad } = require('../utils/ahmadFetch');
    let apps = await fetchAllAhmad();

    // نضيف تطبيقاتك المحلية للقائمة
    try {
      const App = require('../models/App');
      const own = await App.find({});
      apps = [
        ...own.map(a => ({
          name: a.name, bundleId: a.bundleId, version: a.version,
          iconURL: a.iconUrl, category: a.category || '', size: a.size || 0,
          _local: true, _localId: String(a._id)
        })),
        ...apps
      ];
    } catch(le) {}

    // فلترة بالتصنيف
    if (category) apps = apps.filter(a => (a.category||'').trim() === category);
    // فلترة بالبحث
    if (q) apps = apps.filter(a => (a.name||'').toLowerCase().includes(q) || (a.bundleId||'').toLowerCase().includes(q));

    const total = apps.length;
    apps = apps.slice(0, limit);

    // نجيب الـ overrides للتطبيقات المعروضة
    const bundleIds = apps.map(a => a.bundleId);
    const ovs = await AppOverride.find({ bundleId: { $in: bundleIds } });
    const ovMap = {}; ovs.forEach(o => ovMap[o.bundleId] = o);

    const result = apps.map(a => {
      const ov = ovMap[a.bundleId];
      return {
        name: a.name, bundleId: a.bundleId, version: a.version,
        iconURL: a.iconURL, category: a.category, size: a.size,
        hidden: ov?.hidden || false,
        featured: ov?.featured || false,
        moveTo: ov?.moveTo || null,
        addTo: ov?.addTo || [],
        _local: !!a._local
      };
    });
    res.json({ ok: true, apps: result, total });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// حفظ تحكم تطبيق (إخفاء/تمييز/نقل/إضافة)
router.post('/ahmad-apps/override', adminAuth, async (req, res) => {
  try {
    const { bundleId, hidden, featured, moveTo, addTo } = req.body;
    if (!bundleId) return res.status(400).json({ ok:false, message:'bundleId مطلوب' });
    const update = {};
    if (hidden   !== undefined) update.hidden = !!hidden;
    if (featured !== undefined) update.featured = !!featured;
    if (moveTo   !== undefined) update.moveTo = moveTo || null;
    if (addTo    !== undefined) update.addTo = Array.isArray(addTo) ? addTo : [];
    const ov = await AppOverride.findOneAndUpdate(
      { bundleId }, { $set: update }, { upsert: true, new: true }
    );
    res.json({ ok: true, override: ov });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});

// إزالة كل تحكم تطبيق (يرجّع طبيعي)
router.delete('/ahmad-apps/override/:bundleId', adminAuth, async (req, res) => {
  try {
    await AppOverride.findOneAndDelete({ bundleId: req.params.bundleId });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok:false, message: e.message }); }
});


module.exports = router;
