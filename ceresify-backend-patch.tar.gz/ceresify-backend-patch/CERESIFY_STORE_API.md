# واجهات المتجر العامة (Ceresify Store API)

هذا شرح لكل شي ضفته بالسيرفر عشان تطبيق الآيفون يقرا البنرات والفئات من لوحة
التحكم. 3 ملفات تغيّرت/انضافت:

| الملف | التغيير |
|---|---|
| `src/routes/store.js` | **جديد.** فيه `/api/repo.json` و `/api/categories` (بدون توكن — يقرأهم التطبيق مباشرة). |
| `src/app.js` | سطر وحد إضافي: `app.use('/api', require('./routes/store'));` |
| `src/routes/admin.js` | إضافتين بالآخر: `/ahmad-source` و `/ahmad-source/toggle` (بتوكن الأدمن) — هذا هو الجزء المهم، اقرا القسم الجاي. |

---

## ⚠️ السبب المرجّح ليش البنرات ما تطلع

كل من `/ahmad-categories`, `/ahmad-apps` (الموجودين أصلاً باللوحة), و `/api/repo.json`
و `/api/categories` (الجدد) يتوقفون على **مستند Source وحد** بقاعدة البيانات شرطه:

```js
Source.findOne({ type: 'ahmadup', isActive: true })
```

فتّشت بكل اللوحة (`admin.js`, `admin/*.html`) ومو لاقي أي مكان يسوي
`Source.create({ type: 'ahmadup', ... })` — شاشة "إضافة سورس" الموجودة
(`POST /api/admin/sources`) دايماً تنشئ السورس بـ `type: 'altstore'` الافتراضي
ولا توديك تحدد `ahmadup`. يعني **لو ما سويت هذا المستند يدوياً بقاعدة البيانات
قبل، `fetchAllAhmad()` أبداً ما ينفّذ**، فـ`/api/repo.json` يرجع تطبيقات فاضية
→ يرجع `503` → السورس كامل (تطبيقات + بنرات + فئات) ما يطلع بالتطبيق، حتى لو
مفاتيح `AHMADUP_KEY`/`AHMADUP_TOKEN` صحيحة 100%.

**هذا على الأغلب هو سبب "البانرات ابد ما هـنة".**

### الحل (مرة وحدة بس)

ضفتلك راوت جديد بالأدمن يسوي هذا المستند لك، بدل ما تدخل مباشرة لقاعدة البيانات:

```bash
# سجّل دخول أدمن (لو ما عندك توكن جاهز)
TOKEN=$(curl -s -X POST https://dev.ceresify.com/api/admin/login \
  -H "Content-Type: application/json" \
  -d '{"username":"ayman","password":"<باسورد الأدمن مالتك>"}' | jq -r .token)

# فعّل مصدر أحمد
curl -s -X POST https://dev.ceresify.com/api/admin/ahmad-source/toggle \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"isActive": true}'
```

الرد لازم يطلع `{"ok":true,"enabled":true,"source":{...}}`.

للتحقق بأي وقت:
```bash
curl -s https://dev.ceresify.com/api/admin/ahmad-source -H "Authorization: Bearer $TOKEN"
```

**بديل يدوي** (لو تفضل تدخل لقاعدة البيانات مباشرة بـ mongosh):
```js
db.sources.insertOne({
  url: "ahmad-up-integration",
  name: "Ahmad Up",
  type: "ahmadup",
  isActive: true,
  createdAt: new Date()
});
```

> ملاحظة: قيمة `url` هنا شكلية بس — `fetchAllAhmad()` أصلاً يتصل مباشرة بـ
> `https://ahmad-up.com` بمفاتيح `AHMADUP_KEY`/`AHMADUP_TOKEN`/`AHMADUP_DOMAIN`
> من الـ `.env`، هذا المستند بس "مفتاح تشغيل" (on/off).

---

## 1) `GET /api/repo.json` — مصدر AltStore الموحّد

بدون توكن. هذا الرابط اللي التطبيق يضيفه كسورس تلقائياً
(`https://dev.ceresify.com/api/repo.json`).

**من وين يجيب البيانات:**
- `apps`: تطبيقات أحمد (`fetchAllAhmad()`) + تطبيقاتك المحلية المرفوعة (`App` model)،
  بعد تطبيق أي `AppOverride` سويتها بشاشة "ahmad-apps" (إخفاء/نقل فئة/تمييز).
- `news`: كل `Banner` عندها `isActive: true`، مرتبة حسب `order`.

**مثال رد ناجح:**
```json
{
  "identifier": "com.ceresify.store",
  "name": "Ceresify",
  "apps": [
    {
      "bundleIdentifier": "com.example.app",
      "name": "اسم التطبيق",
      "version": "1.2.0",
      "downloadURL": "https://ahmad-up.com/.../app.ipa",
      "iconURL": "https://ahmad-up.com/.../icon.png",
      "size": 123456789,
      "category": "games",
      "localizedDescription": "...",
      "developerName": "ahmad-up"
    }
  ],
  "featuredApps": ["com.example.app"],
  "news": [
    {
      "identifier": "66f0...",
      "title": "",
      "caption": "",
      "imageURL": "https://dev.ceresify.com/uploads/banners/172...-123.png",
      "url": "https://t.me/example",
      "date": "2026-08-01T12:00:00.000Z",
      "notify": false
    }
  ]
}
```

**لو رجّع `503`**: يعني `outApps.length === 0` — إما مصدر أحمد مو مفعّل (شوف
القسم فوق) أو `fetchAllAhmad()` فشل (تحقق `AHMADUP_KEY`/`TOKEN` بالـ `.env`)
ولا عندك تطبيقات محلية بديلة.

**تطبيق بدون `bundleIdentifier` أو `downloadURL` أو `iconURL` صالح يُستبعد
تلقائياً** ولا يدخل بالمصدر إطلاقاً — لأن AltSourceKit (مكتبة التطبيق) ترفض
قراءة *كل* السورس لو تطبيق وحد بس عنده أيقونة فاضية. هذا احترازي مو خطأ.

---

## 2) `GET /api/categories` — فئات سلايدر صفحة "التطبيقات"

بدون توكن. مبني من نفس بيانات شاشة "ahmad-categories" باللوحة (`CategoryOverride`)
+ أسماء الفئات الحيّة الموجودة فعلياً بتطبيقات أحمد. أي فئة `hidden: true` ما
تنرجّع.

```json
{
  "ok": true,
  "categories": [
    { "originalName": "games", "displayName": "ألعاب", "icon": "🎮", "isCustom": false, "customApps": [] },
    { "originalName": null, "displayName": "مفضّلاتي", "icon": "⭐", "isCustom": true, "customApps": ["com.example.app"] }
  ]
}
```

- `isCustom: false` → التطبيق بيهذي الفئة لو `app.category == originalName` بالضبط
  (حساس لحالة الأحرف والمسافات — نفس القيمة اللي راجعة من أحمد أو اللي حطيتها
  بـ `moveTo` override).
- `isCustom: true` → فئة مخصّصة سويتها يدوياً بشاشة categories، تطبيقاتها محددة
  بـ `customApps` (bundleId مباشر) مو بحقل `category`.

سلايدر الفئات بالتطبيق يترتب حسب `order` بالضبط متل ما تحطه بشاشة إعادة الترتيب
باللوحة.

---

## 3) البنرات — مافيه endpoint منفصل، هي جزء من `repo.json`

ما ضفت `/api/banners` مستقل لأن تطبيق الآيفون أصلاً يقرا البنرات كـ "news"
جوة أي سورس AltStore (نفس آلية AltStore القياسية) — فبس خليت بنرات
لوحتك تنعرض كـ `news` جوة `repo.json`. إدارتها 100% من شاشة "Banners"
الموجودة باللوحة (موديل `Banner`، `isActive` + `order`).

---

## 4) قائمة تحقق سريعة لو رجعت المشكلة

```bash
BASE=https://dev.ceresify.com

# 1. مصدر أحمد مفعّل؟
curl -s $BASE/api/admin/ahmad-source -H "Authorization: Bearer $TOKEN"

# 2. الفئات
curl -s $BASE/api/categories | jq

# 3. المصدر الكامل (لازم فيه apps + news)
curl -s $BASE/api/repo.json | jq '{apps: (.apps|length), news: (.news|length)}'

# 4. تحقق إن البنرات فعلاً isActive بقاعدة البيانات
curl -s $BASE/api/admin/banners -H "Authorization: Bearer $TOKEN" | jq
```

لو رقم 3 يرجع `apps: 0` → المشكلة بمصدر أحمد (رقم 1) أو مفاتيح ahmad-up.
لو `apps` فيها رقم بس `news` صفر → تأكد فيه بنرات `isActive: true` فعلاً
(رقم 4).

لو `imageURL` بالبنرات طالعة برابط غلط (مو `https://dev.ceresify.com/...`) —
تأكد `BASE_URL` بملف `.env` مضبوط صح، لأن `store.js` يستخدمه لتحويل مسارات
الرفع النسبية (`/uploads/banners/...`) لروابط كاملة.
