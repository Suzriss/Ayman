// store.js — واجهات عامة (بدون تسجيل دخول) تغذّي تطبيق الآيفون:
// - /api/repo.json  : مصدر AltStore موحّد (تطبيقات أحمد المصنّفة + بنرات لوحة التحكم كـ news)
// - /api/categories : فئات مصدر أحمد الظاهرة للعميل (بعد تطبيق تحكم اللوحة)
//
// كل البيانات هنا تُدار فعلياً من لوحة التحكم (routes/admin.js: Banner, CategoryOverride, AppOverride)
// هذا الملف فقط يعرضها بصيغة يقدر تطبيق الآيفون يقرأها بدون توكن.

const express = require('express');
const router = express.Router();

const Banner = require('../models/Banner');
const CategoryOverride = require('../models/CategoryOverride');
const AppOverride = require('../models/AppOverride');
const Source = require('../models/Source');
const App = require('../models/App');
const { fetchAllAhmad } = require('../utils/ahmadFetch');

const BASE_URL = process.env.BASE_URL || 'https://ceresify.com';

function abs(p) {
  if (!p) return null;
  return /^https?:\/\//i.test(p) ? p : `${BASE_URL}${p.startsWith('/') ? '' : '/'}${p}`;
}

// تجميع تطبيقات أحمد + التطبيقات المحلية، مع تخزين مؤقت خفيف (نفس فكرة ahmadSource.js)
// حتى لا نضرب سيرفر أحمد بطلب لكل تحديث يسويه المستخدمين بنفس اللحظة
let _appsCache = { t: 0, apps: [] };
const APPS_TTL = 5 * 60 * 1000; // 5 دقايق

async function getCombinedApps() {
  if (Date.now() - _appsCache.t < APPS_TTL) return _appsCache.apps;

  let ahmadApps = [];
  const ahmadSrc = await Source.findOne({ type: 'ahmadup', isActive: true });
  if (ahmadSrc) {
    try { ahmadApps = await fetchAllAhmad(); } catch (e) { ahmadApps = []; }
  }

  let localApps = [];
  try {
    const own = await App.find({ isActive: true });
    localApps = own.map(a => ({
      name: a.name,
      bundleId: a.bundleId,
      version: a.version,
      downloadURL: abs(a.ipaPath),
      iconURL: abs(a.iconUrl),
      size: a.size || 0,
      description: a.description || '',
      category: a.category || 'Other',
      developer: 'Ceresify',
    }));
  } catch (e) { /* ignore */ }

  const apps = [...localApps, ...ahmadApps];
  _appsCache = { t: Date.now(), apps };
  return apps;
}

// يبني قائمة الفئات الظاهرة فعلياً (نفس منطق GET /api/admin/ahmad-categories بس بدون عدّادات وبدون المخفي)
async function getVisibleCategories(apps) {
  const counts = {};
  for (const a of apps) {
    const c = (a.category || '').trim();
    if (c) counts[c] = (counts[c] || 0) + 1;
  }

  const overrides = await CategoryOverride.find({});
  const ovMap = {};
  overrides.forEach(o => { if (o.originalName) ovMap[o.originalName] = o; });

  const fromLive = Object.keys(counts).map(name => {
    const ov = ovMap[name];
    return {
      originalName: name,
      displayName: ov?.displayName || name,
      icon: ov?.icon || null,
      hidden: ov?.hidden || false,
      order: ov?.order ?? 999,
      isCustom: false,
      customApps: [],
    };
  });

  const customs = overrides
    .filter(o => o.isCustom)
    .map(o => ({
      originalName: null,
      displayName: o.displayName,
      icon: o.icon,
      hidden: o.hidden,
      order: o.order,
      isCustom: true,
      customApps: o.customApps || [],
    }));

  return [...fromLive, ...customs]
    .filter(c => !c.hidden)
    .sort((a, b) => (a.order - b.order) || a.displayName.localeCompare(b.displayName));
}

// المسار النهائي: /api/categories
router.get('/categories', async (req, res) => {
  try {
    const apps = await getCombinedApps();
    const categories = await getVisibleCategories(apps);
    res.json({ ok: true, categories });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

// المسار النهائي: /api/repo.json
router.get('/repo.json', async (req, res) => {
  try {
    const rawApps = await getCombinedApps();
    const overrides = await AppOverride.find({});
    const ovMap = {};
    overrides.forEach(o => { ovMap[o.bundleId] = o; });

    const outApps = [];
    const featuredApps = [];

    for (const a of rawApps) {
      // بدون bundleId أو رابط تنزيل أو أيقونة صالحة التطبيق ما ينكتب بالمصدر إطلاقاً
      // (أيقونة مفقودة بتطبيق وحد تكسر قراءة كل التطبيقات بمصدر AltStore)
      if (!a.bundleId || !a.downloadURL || !a.iconURL) continue;

      const ov = ovMap[a.bundleId];
      if (ov?.hidden) continue;

      const effectiveCategory = (ov?.moveTo && ov.moveTo.trim()) || a.category || 'Other';

      const base = {
        bundleIdentifier: a.bundleId,
        name: a.name || 'Unknown',
        version: a.version || '1.0',
        versionDate: a.versionDate || a.lastUpdate || a.addDate || undefined,
        downloadURL: abs(a.downloadURL),
        iconURL: abs(a.iconURL),
        size: a.size || 0,
        localizedDescription: a.description || '',
        developerName: a.developer || 'Ceresify',
      };

      outApps.push({ ...base, category: effectiveCategory });

      // addTo: نفس التطبيق يتكرر تحت فئات إضافية يحددها الأدمن (كتصنيف أحمد الأصلي بالضبط)
      if (Array.isArray(ov?.addTo)) {
        for (const extra of ov.addTo) {
          if (extra && extra !== effectiveCategory) {
            outApps.push({ ...base, category: extra });
          }
        }
      }

      if (ov?.featured) featuredApps.push(a.bundleId);
    }

    const activeBanners = await Banner.find({ isActive: true }).sort({ order: 1, createdAt: 1 });
    const news = activeBanners.map(b => ({
      identifier: String(b._id),
      title: '',
      caption: '',
      imageURL: abs(b.imageUrl),
      url: b.linkUrl && b.linkUrl.trim() ? b.linkUrl : undefined,
      date: b.createdAt ? b.createdAt.toISOString() : undefined,
      notify: false,
    }));

    if (outApps.length === 0) {
      // لا نرجّع مصدر بدون تطبيقات أبداً — AltSourceKit يرفض أي مصدر تطبيقاته فاضية
      // (وبالتالي البنرات نفسها ما تظهر لو صار هذا)
      return res.status(503).json({ ok: false, message: 'لا توجد تطبيقات متاحة حالياً' });
    }

    res.json({
      identifier: 'com.ceresify.store',
      name: 'Ceresify',
      apps: outApps,
      featuredApps,
      news,
    });
  } catch (e) {
    res.status(500).json({ ok: false, message: e.message });
  }
});

module.exports = router;
