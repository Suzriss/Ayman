//
//  CeresifyAuthView.swift
//  SY STORE
//
//  شاشة إدخال كود التفعيل — تتحقق عبر لوحة Ceresify.
//

import SwiftUI

struct CeresifyAuthView: View {
    @ObservedObject private var auth = CeresifyAuth.shared
    @State private var codeInput = ""

    private var accent: Color { Color(hex: "#00FF9D") }

    var body: some View {
        ZStack {
            RadialGradient(
                gradient: Gradient(colors: [Color(hex: "#052e16"), .black]),
                center: .bottom, startRadius: 0, endRadius: 600
            ).ignoresSafeArea()

            VStack(spacing: 30) {
                Spacer()

                VStack(spacing: 15) {
                    Image(systemName: "shield.checkered")
                        .font(.system(size: 80, weight: .light))
                        .foregroundColor(accent)
                        .shadow(color: accent.opacity(0.5), radius: 10)
                    Text("SY STORE")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .foregroundColor(.white)
                        .tracking(2)
                    Text("بوابة الوصول الآمن لتطبيقات الـ VIP")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }

                VStack(spacing: 10) {
                    HStack {
                        Image(systemName: "key.fill").foregroundColor(accent)
                        TextField("أدخل كود التفعيل هنا...", text: $codeInput)
                            .foregroundColor(.white)
                            .autocapitalization(.allCharacters)
                            .disableAutocorrection(true)
                            .submitLabel(.go)
                            .onSubmit(activate)
                    }
                    .padding()
                    .background(Color.black.opacity(0.4))
                    .cornerRadius(15)
                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(accent.opacity(0.3), lineWidth: 1))
                    .padding(.horizontal, 30)

                    if let error = auth.errorMessage {
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                    }
                }

                Button(action: activate) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 15)
                            .fill(accent)
                            .shadow(color: accent.opacity(0.4), radius: 10, y: 5)
                        if auth.isChecking {
                            ProgressView().progressViewStyle(CircularProgressViewStyle(tint: .black))
                        } else {
                            Text("تفعيل وتأمين المتجر").font(.headline).bold().foregroundColor(.black)
                        }
                    }
                    .frame(height: 55)
                    .padding(.horizontal, 30)
                }
                .disabled(codeInput.isEmpty || auth.isChecking)

                Spacer()

                Button {
                    if let url = URL(string: "https://t.me/ipa_black") { UIApplication.shared.open(url) }
                } label: {
                    Text("لا تملك رخصة تفعيل؟ تواصل معنا")
                        .font(.footnote)
                        .foregroundColor(.gray)
                        .underline()
                }
                .padding(.bottom, 20)
            }
        }
        .environment(\.colorScheme, .dark)
    }

    private func activate() {
        guard !codeInput.isEmpty, !auth.isChecking else { return }
        Task { await auth.verify(code: codeInput) }
    }
}
